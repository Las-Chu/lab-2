// Project Identifier: 1CAEF3A0FEDD0DEC26BA9808C69D4D22A9962768
//  main.cpp
//  Lab-2
//
//  Created by Laasya Chukka on 1/24/22.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <deque>
#include <utility>
#include <iostream>
#include <getopt.h>
#include "xcode_redirect.hpp"

using namespace std;

int main(int argc, char* argv[]) {
    // insert code here...
    xcode_redirect(argc, argv);
    std::stack<char> stack;
    char temp;
    
    //getline(std::cin, input);
    //std::cout << input;
    while (std::cin){
        char c;
        cin >> c;
        
    
        if (c=='(' || c == '[' || c == '{'){
            stack.push(c);
        }
        
        if (stack.size() == 0){
            std::cout << "Not balanced" << endl;
            break;
        }
        else if (c == ')'){
            temp = stack.top();
            if (temp == '[' || temp == '{'){
                std::cout << "Not balanced" << endl;
                break;
            }
        }
        else if (c == ']'){
            temp = stack.top();
            if (temp == '(' || temp == '{'){
                std::cout << "Not balanced" << endl;
                break;
            }
        }
        else if (c == '}'){
            temp = stack.top();
            if (temp == '[' || temp == '{'){
                std::cout << "Not balanced" << endl;
                break;
            }
        }
        
        if (stack.size() == 0){
            std::cout << "Balanced" << endl;
            break;
        }
        else{
            std::cout << "Not balanced" << endl;
            break;
        }
    }
    return 0;
}

